from django_app.celery_app import app


@app.task()
def make_file(trigger=None):
    if trigger:
        test_file = open('./test-file.txt', 'w')
        test_file.write('Sup, bro! Its task')
        return 'DONE!!!!'

# requests

# 1. While user updated (patch), update weather field. https://openweathermap.org/current
# 2. Create Notification model, (id, text, date, user_id). While new user created, send gratz in 30 days
# 3. periodically tasks. Each 12h, create Notification object with text='SLAVA UKRAINI"




""""
apply_async(
eta=datetime.combine(new_time.today(),
day_info.time_open) +
relativedelta(hours=-3, minutes=10),
args=[company.id, company.phone])
user_info_sms.delay(str(request.user.phone), send_message)

"""
# Django-like urls for tornado

# Import urls to this file end extend `urlpatterns` by them
# from app.urls import tornado_urlpatterns as app_urlpatterns

urlpatterns = []

# urlpatterns.extend(app_urlpatterns)
